﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Model;
using WebApplication1.Model.Repository;
using WebApplication1.Model.DataManager;


namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    public class StudentController : Controller
    {
        private IDataRepository<Student, long> _iRepo;
        public StudentController(IDataRepository<Student, long> repo)
        {
            _iRepo = repo;
        }

        // GET: api/values  
        [HttpGet]
        public IEnumerable<Student> Get()
        {
            return _iRepo.GetAll();
        }

        // GET api/values/5  
        [HttpGet("{id}")]
        public Student Get(int id)
        {
            return _iRepo.Get(id);
        }

        // POST api/values  
        [HttpPost]
        public void Post([FromBody]Student student)
        {
            _iRepo.Add(student);
        }

        // POST api/values  
        [HttpPut]
        public void Put([FromBody]Student student)
        {
            _iRepo.Update(student.StudentId, student);
        }

        // DELETE api/values/5  
        [HttpDelete("{id}")]
        public long Delete(int id)
        {
            return _iRepo.Delete(id);
        }
    }
}